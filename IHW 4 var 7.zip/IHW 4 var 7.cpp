﻿#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <condition_variable>
#include <algorithm>
#include <random>
#include <chrono>
#include <fstream>
#include <sstream>
#include <cstring>

class DatabaseGenerator {
public:
  // This class is responsible for generating the initial database file
  static void generate(const std::string& filename, int size) {
    std::ofstream file(filename);
    if (!file) {
      std::cerr << "Error creating file: " << filename << '\n';
      return;
    }

    // Fill the file with random numbers
    for (int i = 0; i < size; ++i) {
      file << rand() % 10000 << "\n";
    }

    file.close();
    std::cout << "Database with " << size << " entries created in file: " << filename <<  '\n';
  }
};

class DatabaseIO {
public:
  // Load data from a file into a vector.
  static void load(const std::string& filename, std::vector<int>& data) {
    std::ifstream file(filename);
    if (!file) {
      std::cerr << "Error reading file: " << filename << '\n';
      return;
    }

    int value;
    while (file >> value) {
      data.push_back(value);
    }

    file.close();
  }

  // Save data from a vector to a file.
  static void save(const std::string& filename, const std::vector<int>& data) {
    std::ofstream file(filename);
    if (!file) {
      std::cerr << "Error writing file: " << filename << '\n';
      return;
    }

    for (const int& value : data) {
      file << value << "\n";
    }

    file.close();
  }
};

class Logger {
  std::mutex log_mtx; // Protects access to the log file
  std::ofstream log_file;

public:
  // Initialize the logger with the log file name.
  Logger(const std::string& log_filename) {
    log_file.open(log_filename, std::ios::out);
    if (!log_file) {
      std::cerr << "Error creating log file: " << log_filename << '\n';
    }
    else {
      // Write the header for CSV (I din't understand what output to file should be so i've chosen csv).
      log_file << "Type,ProcessID,Index,OldValue,NewValue,Timestamp\n";
    }
  }

  ~Logger() {
    if (log_file.is_open()) {
      log_file.close();
    }
  }

  // Log an operation (read or write) with all relevant details.
  void log(const std::string& type, int process_id, int index, int old_value, int new_value) {
    std::lock_guard<std::mutex> lock(log_mtx);
    if (log_file.is_open()) {
      std::ostringstream oss;
      auto now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
      oss << type << "," << process_id << "," << index << ",";
      oss << (old_value == -1 ? "-" : std::to_string(old_value)) << ",";
      oss << (new_value == -1 ? "-" : std::to_string(new_value)) << ",";
      #pragma warning(suppress : 4996) // To fix C4996 (i don't understand why it occured).
      oss << std::put_time(std::localtime(&now), "%Y-%m-%dT%H:%M:%S") << "\n";
      log_file << oss.str();
    }
  }
};

class Database {
  std::vector<int> data; // The main database.
  std::mutex mtx; // Mutex for protecting access to the database.
  std::condition_variable cv; // Condition variable for readers and writers.
  int readers_count = 0; // Active readers count.
  bool writer_active = false; // Is there an active writer?
  Logger& logger; // Logger instance for recording operations.

public:
  Database(const std::vector<int>& initial_data, Logger& log) : data(initial_data), logger(log) {}

  // Simulates a read operation by a reader
  void read(int reader_id) {
    std::unique_lock<std::mutex> lock(mtx);
    while (writer_active) {
      cv.wait(lock);
    }
    ++readers_count;
    lock.unlock();

    // Reading
    int index = rand() % data.size();
    int value = data[index];
    std::cout << "Reader " << reader_id << " read index " << index << ", value " << value << std::endl;
    logger.log("Read", reader_id, index, value, -1);

    lock.lock();
    --readers_count;
    if (readers_count == 0) {
      cv.notify_all();
    }
  }

  // Simulates a write operation by a writer
  void write(int writer_id) {
    std::unique_lock<std::mutex> lock(mtx);
    while (writer_active || readers_count > 0) {
      cv.wait(lock);
    }
    writer_active = true;

    // Writing
    int index = rand() % data.size();
    int old_value = data[index];
    int new_value = rand() % 100;
    data[index] = new_value;
    std::sort(data.begin(), data.end()); // Keep the database sorted
    std::cout << "Writer " << writer_id << " wrote index " << index << ", old value " << old_value << ", new value " << new_value << std::endl;
    logger.log("Write", writer_id, index, old_value, new_value);

    writer_active = false;
    cv.notify_all();
  }

  const std::vector<int>& get_data() const {
    return data;
  }
};

void reader_task(Database& db, int reader_id, int max_operations) {
  for (int i = 0; i < max_operations; ++i) {
    db.read(reader_id);
    std::this_thread::sleep_for(std::chrono::milliseconds(100)); // Simulate delay.
  }
}

void writer_task(Database& db, int writer_id, int max_operations) {
  for (int i = 0; i < max_operations; ++i) {
    db.write(writer_id);
    std::this_thread::sleep_for(std::chrono::milliseconds(200)); // Dealay.
  }
}

int main(int argc, char* argv[]) {
  srand(time(0));

  std::string db_filename = "database.txt";
  std::string log_filename = "operations_log.txt";
  int db_size = 10000;
  int max_operations = 100; // Number of operations per thread
  int num_readers = 5;
  int num_writers = 2;

  // Parse command-line arguments
  for (int i = 1; i < argc; ++i) {
    if (strcmp(argv[i], "-db") == 0 && i + 1 < argc) {
      db_filename = argv[++i];
    }
    else if (strcmp(argv[i], "-log") == 0 && i + 1 < argc) {
      log_filename = argv[++i];
    }
    else if (strcmp(argv[i], "-size") == 0 && i + 1 < argc) {
      db_size = std::stoi(argv[++i]);
    }
    else if (strcmp(argv[i], "-readers") == 0 && i + 1 < argc) {
      num_readers = std::stoi(argv[++i]);
    }
    else if (strcmp(argv[i], "-writers") == 0 && i + 1 < argc) {
      num_writers = std::stoi(argv[++i]);
    }
    else if (strcmp(argv[i], "-ops") == 0 && i + 1 < argc) {
      max_operations = std::stoi(argv[++i]);
    }
  }

  // Generate initial database
  DatabaseGenerator::generate(db_filename, db_size);

  // Load database from file
  std::vector<int> initial_data;
  DatabaseIO::load(db_filename, initial_data);

  Logger logger(log_filename);
  Database db(initial_data, logger);

  std::vector<std::thread> readers;
  std::vector<std::thread> writers;

  // Start reader threads
  for (int i = 0; i < num_readers; ++i) {
    readers.emplace_back(reader_task, std::ref(db), i, max_operations);
  }

  // Start writer threads
  for (int i = 0; i < num_writers; ++i) {
    writers.emplace_back(writer_task, std::ref(db), i, max_operations);
  }

  // Wait for all reader threads to finish
  for (auto& reader : readers) {
    reader.join();
  }

  // Wait for all writer threads to finish
  for (auto& writer : writers) {
    writer.join();
  }

  // Save updated database to file
  DatabaseIO::save(db_filename, db.get_data());

  return 0;
}
